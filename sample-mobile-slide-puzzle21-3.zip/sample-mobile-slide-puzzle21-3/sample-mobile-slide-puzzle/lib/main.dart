// Copyright 2020, the Flutter project authors. Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

import 'package:provider/provider.dart';
import 'package:slide_puzzle/src/core/DarkThemeProvider.dart';
import 'package:splashscreen/splashscreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_agenda/flutter_agenda.dart';

import 'src/core/puzzle_animator.dart';
import 'src/flutter.dart';
import 'src/puzzle_home_state.dart';

void main() => runApp(const PuzzleApp());

class PuzzleApp extends StatefulWidget {
  final int rows, columns;

  const PuzzleApp({this.columns = 4, this.rows = 4});
  static final ValueNotifier<ThemeMode> themeNotifier =
      ValueNotifier(ThemeMode.light);

  @override
  State<PuzzleApp> createState() => PuzzleAppState();
}

class PuzzleAppState extends State<PuzzleApp> {
  //
//   late AnimationController _controller;
// //
//   late Animation<Alignment> _animation;

  Alignment _dragAlignment = Alignment.center;
  //
DarkThemeProvider themeChangeProvider = new DarkThemeProvider();

  @override
  void initState() {
    super.initState();
     getCurrentAppTheme();
    // _controller =
    //     AnimationController(vsync: this, duration: const Duration(seconds: 1));
  }

void getCurrentAppTheme() async {
  themeChangeProvider.darkTheme =
      await themeChangeProvider.darkThemePreference.getTheme();
}
  @override
  void dispose() {
    //_controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ChangeNotifierProvider(
        create: (_) {
          return themeChangeProvider;
        },
       child: Consumer<DarkThemeProvider>(
          builder: (BuildContext context, value, Widget child)
           {
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              theme: Styles.themeData(themeChangeProvider.darkTheme, context),
              home: SplashScreen(),
                   },
            
          
        ),);}
// @override
//   Widget build(BuildContext context) {
//     return
//       ChangeNotifierProvider(
//         create: (_) {
//           return themeChangeProvider;
//         },
//         child: Consumer<DarkThemeProvider>(
//           builder: (BuildContext context, value, Widget child) {
        //     return MaterialApp(
        //       debugShowCheckedModeBanner: false,
        //       theme: Styles.themeData(themeChangeProvider.darkTheme, context),
        //       home: SplashScreen(),
        //       routes: <String, WidgetBuilder>{
        //         AGENDA: (BuildContext context) => AgendaScreen(),
        //       },
        //     );
        //   },
        // ),);
class _PuzzleHome extends StatefulWidget
{ 
  final int _rows, _columns;

  const _PuzzleHome(this._rows, this._columns);

  @override
  PuzzleHomeState createState() =>
      PuzzleHomeState(PuzzleAnimator(_columns, _rows));
}
